# Bachelorarbeit – Quellcode des robotischen Greifsystems

**Entwicklung und Evaluierung eines robotischen Greifsystems mit KI-gestützter Bildverarbeitung und Bewegungsplanung zur Wellenentnahme**
Kaan Kirac · Fachhochschule Südwestfalen, Fachbereich Maschinenbau, Iserlohn · Erstprüfer Prof. Dr. Martin Skambraks · Zweitprüfer Prof. Dr. Tobias Ellermeyer · Bearbeitungszeitraum 01.08.–03.10.2026

Dieses Repository enthält den **gesamten selbst geschriebenen Quellcode** des Versuchssystems sowie das Entwicklungsprotokoll. Es ist der digitale Anhang zur Bachelorarbeit; die Abschnittsnummern unten beziehen sich auf die Arbeit (Kapitel 5 = Implementierung, Kapitel 6 = Evaluation, Kapitel 7 = Diskussion).

> **Hinweis zum Stand.** Der Quellcode im Ordner `quellcode/` wurde zuletzt am **28.09.2026** geändert und ist seitdem unverändert (die Arbeit verweist auf das Repository mit „Stand: 01.10.2026“). Nach der Abgabe wurden **ausschließlich Begleitdokumente** ergänzt bzw. korrigiert (README, `DATEIEN.md`, Installationshinweise, Entwicklungsprotokoll) und **fehlende Binärdateien nachgereicht** (STL-Meshes, aufgezeichnete Kameraszenen, Rohdaten des Versuchsprotokolls, Modellgewichte als Release-Anhang), die beim ursprünglichen Hochladen nicht übertragen worden waren; am Quellcode selbst wurde nichts geändert. Die Änderungen sind in Abschnitt 9 aufgeführt und in der Versionsgeschichte des Repositorys nachvollziehbar.

## 1. Inhalt des Repositorys

| Datei / Ordner | Inhalt |
|---|---|
| `quellcode/` | 1:1-Kopie aller eigenen Quell-, Konfigurations- und Datendateien des ROS-2-Workspace `~/ros2_ws` (201 Text-Dateien mit rund 43 400 Zeilen sowie die STL-Meshes der Szene) – Ordnerstruktur wie auf dem Roboter |
| `DATEIEN.md` | **Verzeichnis aller Dateien mit je einer Kurzbeschreibung** (aus den Docstrings erzeugt) – der schnellste Einstieg |
| `ALLE_CODES.txt` | Alle Dateien in **einer** Textdatei mit Inhaltsverzeichnis (zum Suchen, Lesen, Drucken) |
| `DEVLOG_de.md` | Entwicklungsprotokoll (deutsch), jede Sitzung von Mai bis September 2026: Befunde, Messungen, Entscheidungen, Unfälle und ihre Ursachen |
| `quellcode/testdaten/` | aufgezeichnete RGB-D-Szenen der Bereitstellungsschale vom 13.09.2026 (u. a. 11 bzw. 12 Wellen, Abschnitt 5.8.2) als NumPy-Archive; damit lässt sich die Wellen- und Kopfseitenerkennung ohne Kamera nachvollziehen |
| `quellcode/zyklus_protokoll.txt`, `quellcode/zyklus_log.jsonl` | Rohprotokoll der Ablaufsteuerung `tools/zyklus_gui.py` (Text bzw. ein JSON-Eintrag je Ereignis) |
| Release `v1.0-abgabe` | trainierte YOLO11l-seg-Gewichte `welle_gross.pt` (Abschnitt 5.3.2) als Release-Anhang (Datei zu groß für das Repository selbst) |

**Zur Datei- und Zeilenzahl:** Die Arbeit nennt in der Einleitung zu Kapitel 5 „154 Dateien, rund 32 900 Zeilen“. Diese Zählung bezieht sich auf den Stand 14.09.2026 und umfasst nur Python-, C++-, Xacro-/URDF-, YAML-/SRDF- und Shell-Dateien. Die Zahl oben (201 Dateien) bezieht sich auf den Endstand 28.09.2026 und schließt zusätzlich JSON-Datendateien (Teach-Punkte, Messwerte, Farbreferenzen), Markdown-Notizen und RViz-Konfigurationen ein.

**Nicht enthalten** (Fremdcode oder Binärdaten): die übernommenen Upstream-Pakete `mycobot_ros2` (Elephant Robotics), `realsense2_camera`/`realsense2_description`, `easy_handeye2` und `trac_ik` (für Galactic portiert; Bezugsquellen in Abschnitt 6), die frühere Modellvariante `v2_best.pt` (20 MB), der Bilddatensatz (287 Aufnahmen; separates Repository `-robot-vida-projesi_large` bzw. Datenträger) sowie `build/`, `install/`, `log/`.

## 2. Was das System tut

Sechsachsiger myCobot 280 JN (Jetson Nano, ROS 2 Galactic) mit stationärer RGB-D-Kamera Intel RealSense D435if (Eye-to-Hand). Ein Handhabungszyklus (`tools/zyklus_gui.py`, Abschnitt 5.10 der Arbeit):

1. Kamerapose prüfen (`tools/kamera_pruefung.py`, `tools/measure_camera_pose.py`)
2. Zielwelle in der Bereitstellungsschale bestimmen: Instanzsegmentierung mit YOLO11-seg (`src/wellenerkennung`) bzw. modellbasierte Erkennung (`tools/welle_finden_schale.py`), Bewertung 0–100 je Kandidat (Wandabstand, Nachbarabstand, Form, Kopfseite, Farbsicherheit, Lage)
3. Zielnest aus Körper- und Streifenfarbe (`tools/welle_farbe.py`, `tools/nest_fuer_farbe.py`, `farbplan.json`)
4. Welle greifen: IK mit TRAC-IK über `/compute_ik`, freie Anfahrt mit MoveIt 2/OMPL, gerade Absenkung über `/compute_cartesian_path` mit Stetigkeitsprüfung (`tools/hole_aus_schale.py`, `tools/bahnpruefung.py`)
5. Kontrollpose unter der Kamera, Kopfseite prüfen (`tools/kontrollpose.py`, `tools/kopfseite_pruefen.py`)
6. Übergabe an das trichterförmige Übergabeelement (`tools/lege_welle.py --nest trichter_ablager`)
7. Kamerakontrolle: steht die Welle im Trichter?
8. Wiederaufnahme am Kopf (`tools/hole_welle.py`)
9. Vertikale Ablage im Zielnest der Versuchsplatte in einer einzigen Absenkbahn mit Encoder-Vorhalt (`tools/lege_welle.py`, `tools/nachstellen.py`, `tools/gelenkspiel.py`)

Die Roboterhardware ist über `ros2_control` angebunden: das C++-Hardware-Interface (`src/mycobot_hardware/src/mycobot_hardware.cpp`) spricht über einen Unix-Socket mit der Python-Brücke `src/mycobot_hardware/scripts/mycobot_bridge.py`, die als einziger Prozess die serielle Schnittstelle (`pymycobot`) besitzt, den Encoder-Nullpunktversatz kompensiert und den NOT-AUS (`estop_relay.py`, `estop_button.py`) durchsetzt.

## 3. Eigene ROS-2-Pakete (`quellcode/src/`)

| Paket | Aufgabe | Arbeit |
|---|---|---|
| `mycobot_world` | URDF/Xacro der Gesamtszene: Roboter, Greifer, Kamera, Grundplatte, Schale, Trichter, Ablageplatte; Kamerapose; Reichweitenmarker | 5.6.1, 5.6.6 |
| `mycobot_moveit_config` | MoveIt-2-Konfiguration: SRDF, TRAC-IK (`kinematics.yaml`), OMPL/RRTConnect (`ompl_planning.yaml`), Controller, Startskript `demo.launch.py` | 5.6.2–5.6.3 |
| `mycobot_hardware` | ros2_control-Hardware-Interface + Python-Brücke zur seriellen Steuerung, NOT-AUS-Relais | 5.1, 5.10 |
| `wellenerkennung` | YOLO11-seg-Detektor als ROS-2-Knoten: Instanzmasken, PCA-Orientierung, robuste Tiefe (Median/MAD), Rückprojektion, Zielpose in `robot_base` | 5.3, 5.4 |
| `mycobot_calibration` | ChArUco-Detektor (solvePnP), Hand-Eye-Kalibrierung (calibrateHandEye: Park/Horaud/Daniilidis), Kalibrier-Launchfiles, Jog- und Klick-Werkzeuge, NOT-AUS-Taster | 5.5 |
| `mycobot_demo` | frühe C++-Demos (MoveGroupInterface): Anfahrt, Pick & Place, Klickpunkt | 5.11 |

## 4. Die wichtigsten Programme (`quellcode/tools/` und Wurzel)

| Datei | Zweck | Arbeit |
|---|---|---|
| `start_mycobot.sh` / `stop_mycobot.sh` | gesamten Stack starten (LC_ALL=C, CycloneDDS nur loopback, Kamera 848×480@15, Fixtures per Umgebungsvariable `SCHALE_MONTIERT`, `TRICHTER_MONTIERT`, `ABLAGEPLATTE_MONTIERT`) bzw. sauber beenden | 5.1 |
| `ros_umgebung.sh` | Terminalumgebung für alle `tools/*.py` | – |
| `tools/zyklus_gui.py` | grafische Ablaufsteuerung: AUTOMATIK/MANUELL, Start ab beliebigem Schritt, Farbwahl durch den Bediener, Nestabfrage, NOT-AUS, Protokoll `zyklus_protokoll.txt` | 5.10 |
| `tools/ablauf.py` | Kette der Einzelschritte ohne Fenster (`--von schale`, `--auto`) | 5.10 |
| `tools/welle_finden_schale.py` | modellbasierte Wellenerkennung in der Schale (Stabanpassung, Kopfseite aus Breitenprofil und Ringen, Konfidenz 0–100, IK-Probe je Kandidat) | 5.3.3, 5.8.2 |
| `tools/welle_farbe.py`, `tools/nest_fuer_farbe.py` | Körper- und Streifenfarbe (HSV-Referenzen `farbklassen.json`) → Zielnest (`farbplan.json`) | 5.9 |
| `tools/hole_aus_schale.py` | Griff aus der Schale: IK-Haltung, Pre-Grasp, gerade Absenkung, Greifer, Anheben | 5.6.4 |
| `tools/kontrollpose.py`, `tools/kopfseite_pruefen.py`, `tools/kamera_pruefung.py` | Kontrollpose unter der Kamera und Kopfseitenkontrolle | 5.8.2 |
| `tools/hole_welle.py` | Wiederaufnahme der Welle aus dem Trichter am Kopf | 5.8.3 |
| `tools/lege_welle.py` | Ablage im Nest (eine Absenkbahn mit Vorhalt, Nachstellen über dem Nest, Freigabegrenze 4 mm) und Übergabe an den Trichter | 5.9.2, 6.8 |
| `tools/nachstellen.py`, `tools/gelenkspiel.py`, `tools/j4_von_oben.py` | Kompensation von Totband und richtungsabhängigem Getriebespiel (Achsen 2 und 4 von oben, Vorhalt) | 6.7 |
| `tools/bahnpruefung.py` | Stetigkeitsprüfung jeder kartesischen Bahn (Pflicht seit dem Unfall vom 13.09.2026) | 5.6.5 |
| `tools/nullstellung_moveit.py`, `go_to_zero.sh`, `tools/hebe_und_parke.py` | kollisionsgeprüfte Fahrt in die reale Nullstellung | 5.10 |
| `tools/nest_anfahren.py`, `tools/versetze_soll.py`, `tools/teach_*.py`, `tools/servo_nullen.py` | Anlernen und Nachjustieren der Nester, Teach-Punkte, Servo-Nullpunkt | 5.9.2 |
| `tools/measure_camera_pose.py`, `tools/pruefe_kalibrierung_platte.py`, `tools/kamerapose.py` | plattenbasierte Bestimmung und Prüfung der Kamerapose (RANSAC-Ebene, Rechteckkanten) | 5.5.2, 5.5.3 |
| `tools/calibrate_handeye_auto.py`, `src/mycobot_calibration/scripts/calibrate_handeye.py` | Hand-Eye-Kalibrierung mit ChArUco (16 Posen) | 5.5.1 |
| `tools/kamera_roboter_abbildung.py` | Abbildung Kamera → Modell im Arbeitsbereich messen und fitten | 5.5 |
| `tools/schale_finden*.py`, `tools/schale_erreichbarkeit.py`, `tools/arbeitsraum_grenze.py` | Lage der Schale aus Tiefen-/Farbbild, Erreichbarkeit, nutzbarer Arbeitsraum | 5.6.6 |
| `tools/gelenkspiel_messreihe.py`, `tools/measure_*.py`, `measure_zero.py` | Messreihen: Gelenkspiel, Modellgenauigkeit, Kamerahöhe, Nachgiebigkeit | 6.7 |
| `tools/jog_gui.py`, `tools/jog_ohne_drehung.py`, `tools/servo_frei.py` | Handjog, Servo freischalten zum Führen von Hand | – |
| `tools/export_code_single_file.py` | erzeugt `ALLE_CODES.txt` | – |

Weitere Werkzeuge und alle Daten-/Konfigurationsdateien sind in `DATEIEN.md` beschrieben.

## 5. Wichtige Daten- und Konfigurationsdateien

| Datei | Inhalt |
|---|---|
| `teach_punkte.json` | angelernte Gelenkstellungen (Nullstellung, 20 Nester `nest_XY_ablage`, `trichter_greif`, `trichter_ablager`, Kontrollposen) – im Modellraum (Encoder − Versatz) |
| `gelenk_nullpunkte.json` | Encoder-Nullpunktversatz je Gelenk `[0, 2.29, 0.29, −0.29, 0, 0]°`, von der Brücke kompensiert |
| `farbplan.json`, `farbklassen.json` | Zuordnung Farbe → Nest; gelernte HSV-Referenzen |
| `platte_belegung.json` | aktuelle Belegung der Nester |
| `kamera_modell_platte.json`, `src/mycobot_world/urdf/camera_pose.xacro` | plattenbasiert bestimmte Kamerapose |
| `src/mycobot_moveit_config/config/*.yaml`, `mycobot.srdf` | IK, Planer, Controller, erlaubte Kollisionspaare |

## 6. Installation und Ausführung

Das System wurde auf dem im myCobot 280 JN integrierten Jetson Nano entwickelt. Ohne Roboter und Kamera lassen sich **Robotermodell, Versuchsaufbau, Bewegungsplanung und Trajektorienausführung in der Simulation** (ros2_control-Fake-Hardware) nachvollziehen; die Bildverarbeitung benötigt die Kamera bzw. aufgezeichnete Bilder und die Modellgewichte.

### 6.1 Voraussetzungen

| Komponente | Im Versuch verwendeter Stand (Tabelle 5-1 der Arbeit) | Bezugsquelle |
|---|---|---|
| Betriebssystem | Ubuntu 20.04 LTS (ROS 2 Galactic ist nur für 20.04 verfügbar) | – |
| ROS 2 | Galactic (`ros-galactic-desktop`, `ros-galactic-moveit` 2.3.x, `ros-galactic-ros2-control`, `ros-galactic-ros2-controllers`, `ros-galactic-xacro`) | apt (packages.ros.org) |
| `mycobot_ros2` (liefert `mycobot_description`) | Zweig `galactic`, Commit `3999e2c` | <https://github.com/elephantrobotics/mycobot_ros2> |
| `trac_ik` | Zweig `rolling`, Commit `56136bb` (Release 2.2.0), für Galactic gebaut | <https://github.com/traclabs/trac_ik> |
| `realsense2_camera` | 4.51.1 (nur am realen Roboter nötig) | <https://github.com/IntelRealSense/realsense-ros> (Tag `4.51.1`) |
| `realsense2_description` | Kamera-Makro mit Parameter `use_mesh` (erst ab Tag `4.58.4` enthalten) | <https://github.com/IntelRealSense/realsense-ros> (Tag `4.58.4`) |
| `easy_handeye2` (nur für die Kalibrier-Launchfiles) | ROS-2-Version | <https://github.com/marcoesposito1988/easy_handeye2> |
| Python-Pakete | siehe `requirements.txt` (u. a. `ultralytics` 8.4.33, `opencv` 4.8.0, `pymycobot` 4.0.4; im Versuch die Vorabversion 4.0.4b5) | pip |

> **Hinweis:** ROS 2 Galactic ist seit Dezember 2022 ohne Herstellerunterstützung (End of Life). Die Pakete sind weiterhin über das ROS-Archiv bzw. ein Docker-Image `ros:galactic` installierbar. Für einen Nachbau ohne Ubuntu 20.04 ist ein solches Docker-Image der einfachste Weg.

### 6.2 Workspace bauen

Die Skripte erwarten den Workspace unter `~/ros2_ws` (Ordnerstruktur wie auf dem Roboter):

```bash
git clone https://github.com/kakir001/bachelorarbeit-ros2-code.git
mkdir -p ~/ros2_ws && cp -r bachelorarbeit-ros2-code/quellcode/. ~/ros2_ws/
cd ~/ros2_ws/src
git clone -b galactic https://github.com/elephantrobotics/mycobot_ros2.git && git -C mycobot_ros2 checkout 3999e2c
git clone -b rolling  https://github.com/traclabs/trac_ik.git          && git -C trac_ik checkout 56136bb
git clone -b 4.58.4   https://github.com/IntelRealSense/realsense-ros.git   # für die Simulation reicht realsense2_description
# Tippfehler im Upstream-URDF (Commit 3999e2c) beheben, sonst bricht xacro mit „XML parsing error“ ab:
sed -i 's/lower = "-2.932"1 upper/lower = "-2.9321" upper/' \
    mycobot_ros2/mycobot_description/urdf/mycobot_280_jn/mycobot_280_jn_adaptive_gripper.urdf
cd ~/ros2_ws
pip3 install -r ~/bachelorarbeit-ros2-code/requirements.txt   # Pfad ggf. anpassen
source /opt/ros/galactic/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --packages-skip realsense2_camera   # Kameratreiber nur am realen Roboter bauen
```

Geprüft (04.10.2026): Mit diesen Upstream-Ständen lässt sich die Gesamtszene `mycobot_world.urdf.xacro` (Fake- und Echt-Hardware, mit Schale, Trichter und Ablageplatte) fehlerfrei expandieren; das Modell ist ein zusammenhängender Baum mit Wurzel `robot_base` (82 Links, 81 Gelenke), alle Gelenke der Controller-Konfiguration sind im Modell vorhanden, und die Grenze der ersten Achse beträgt ±2,9321 rad (±168°, Tabelle 2-3).

Die Modellgewichte `welle_gross.pt` aus dem Release `v1.0-abgabe` herunterladen, in den Ordner `~/ros2_ws/src/wellenerkennung/weights/` legen (`mkdir -p` falls nicht vorhanden) und das Paket erneut bauen (`colcon build --packages-select wellenerkennung`); ohne diese Datei startet der Detektorknoten nicht.

Falls `trac_ik` nicht baut, kann zum reinen Betrachten der Planung in `src/mycobot_moveit_config/config/kinematics.yaml` vorübergehend `kdl_kinematics_plugin/KDLKinematicsPlugin` eingetragen werden; die im Versuch verwendete Konfiguration ist TRAC-IK (Quelltext 5-8).

### 6.3 Simulation ohne Roboter (MoveIt 2 + RViz 2, Fake-Hardware)

```bash
cd ~/ros2_ws && source install/setup.bash
export LC_ALL=C LC_NUMERIC=C LANG=C          # Qt/RViz: Dezimalpunkt statt Komma
USE_FAKE_HARDWARE=true SCHALE_MONTIERT=1 TRICHTER_MONTIERT=1 ABLAGEPLATTE_MONTIERT=1 \
  ros2 launch mycobot_moveit_config demo.launch.py use_camera:=false
```

RViz 2 zeigt den modellierten Versuchsaufbau (Abbildung 5-6 der Arbeit); über das MotionPlanning-Panel lassen sich Ziele planen und mit der Fake-Hardware ausführen. `start_mycobot.sh sim` ist für den Jetson gedacht (startet zusätzlich Kamera und Kamera-Posenprüfung) und auf einem Rechner ohne Kamera nicht zu empfehlen.

**Bekannte Einschränkung beim Nachbau:** Einige Mess- und Kalibrierwerkzeuge in `tools/` (`calibrate_handeye_auto.py`, `measure_*.py`, `test_position_retry.py`, `zeichne_greifer.py`) sowie `go_to_zero.sh` enthalten den absoluten Pfad `/home/er/ros2_ws` des Jetson. Auf einem anderen Rechner diese Werkzeuge entweder unter einem Benutzer `er` ausführen oder einen symbolischen Link anlegen: `sudo mkdir -p /home/er && sudo ln -s ~/ros2_ws /home/er/ros2_ws`. Die ROS-2-Pakete unter `src/` und die Ablaufsteuerung (`tools/zyklus_gui.py`) sind davon nicht betroffen.

### 6.4 Betrieb am realen Roboter (Jetson Nano)

```bash
# Terminal 1 – Stack (Roboter, MoveIt 2, RViz 2, Kamera, Brücke, NOT-AUS)
SCHALE_MONTIERT=1 TRICHTER_MONTIERT=1 ABLAGEPLATTE_MONTIERT=1 KAMERA_PROFIL=848 ./start_mycobot.sh
# Terminal 2 – Umgebung + Ablaufsteuerung
source ros_umgebung.sh
python3 tools/zyklus_gui.py            # MANUELL: jeder Schritt wird bestätigt
```
Sicherheitsregeln des Projekts (Abschnitt 7.4): Bewegungen nur über MoveIt 2 (kollisionsgeprüft, Stetigkeitsprüfung), niedrige Geschwindigkeit, jede neue Bewegung zuerst in RViz 2 ansehen; der Herstellerbefehl `send_coords` wird nicht verwendet. Ein Stack-Neustart in der Nähe des Trichters ist zu vermeiden (automatische Nullstellung ist deaktiviert).

## 7. Hinweise zum Lesen des Codes

* Kommentare und Docstrings sind überwiegend deutsch; frühe Dateien (Mai/Juni 2026) sind englisch kommentiert, einige Werkzeuge verwenden ASCII-Umlaute (ae/oe/ue), damit sie in jedem Terminal lesbar bleiben.
* Jede Datei beginnt mit einem Docstring, der Zweck, Aufruf und – wo relevant – das Datum und den Anlass der Änderung nennt (z. B. `tools/bahnpruefung.py`: Unfall vom 13.09.2026).
* Die in der Arbeit abgedruckten Quelltexte 5-1 bis 5-11 und 6-1 sind gekürzte Auszüge aus `mycobot_bridge.py`, `erkennung.py`, `wellen_detektor_node.py`, `charuco_detector.py`, `calibrate_handeye.py`, `measure_camera_pose.py`, `kinematics.yaml`, `hole_aus_schale.py`, `bahnpruefung.py` und `nachstellen.py`.
* Abweichung Arbeit ↔ Code: In Abschnitt 7.10 und im Kommentar von Quelltext 6-1 ist eine Setzzeit von 3 s genannt. Im Ablauf übernimmt `tools/lege_welle.py` das Nachstellen mit bis zu 4 Runden (wie in der Arbeit) und einer Setzzeit von **4 s**; das eigenständige Werkzeug `tools/nachstellen.py` verwendet ohne Aufrufparameter 3 Runden und 5 s.
* Das Entwicklungsprotokoll `DEVLOG_de.md` ist chronologisch rückwärts sortiert (neueste Sitzung oben) und enthält zu jeder Messung die Rohwerte.

## 8. Zugriff

Das Repository ist **öffentlich** lesbar (kein Sperrvermerk). Der vollständige Workspace mit Versionsgeschichte liegt zusätzlich unter `github.com/kakir001/ros2_ws` (privat).

## 9. Änderungen nach der Abgabe (nur Dokumentation)

| Datum | Änderung |
|---|---|
| 04.10.2026 | README: Abschnittsnummern an die Kapitelzählung der Arbeit angepasst (Implementierung = Kapitel 5, Evaluation = Kapitel 6); Hinweis zum Stand und zur Datei-/Zeilenzahl; Installations- und Simulationsanleitung (Abschnitt 6); Hinweis auf die Setzzeit-Abweichung |
| 04.10.2026 | `DATEIEN.md` aus den Docstrings erzeugt, `requirements.txt` ergänzt |
| 05.10.2026 | `DEVLOG_de.md` und Modellgewichte (Release `v1.0-abgabe`) nachgereicht, die in der ursprünglichen README bereits genannt waren |
| 05.10.2026 | Binärdateien des Workspace nachgereicht, die beim ursprünglichen Hochladen (nur Textdateien) nicht übertragen worden waren: sechs STL-Meshes in `quellcode/src/mycobot_world/meshes/` (ohne diesen Ordner bricht `colcon build` des Pakets `mycobot_world` ab), aufgezeichnete Kameraszenen in `quellcode/testdaten/` sowie die Hintergrundaufnahmen `schale_hintergrund.npz` und `trichter_hintergrund.npz` |
| 05.10.2026 | Rohdaten des Versuchsprotokolls nachgereicht: `quellcode/zyklus_protokoll.txt` und `quellcode/zyklus_log.jsonl` (von der Ablaufsteuerung `tools/zyklus_gui.py` geschrieben, letzte Änderung 24.09.2026) |

Quell- und Konfigurationsdateien in `quellcode/` sowie `ALLE_CODES.txt` sind gegenüber dem Stand vom 28.09.2026 unverändert; ergänzt wurden nur die oben genannten Binärdateien.
